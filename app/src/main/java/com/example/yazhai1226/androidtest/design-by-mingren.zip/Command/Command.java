package com.example.yazhai1226.androidtest.Command;

/**
 * Created by MingRen on 2016/8/29.
 * email:674928145@qq.com
 * address:shenzhen
 */
public interface Command {
    void sing();
}
