package com.example.yazhai1226.androidtest.mvp.modle;

/**
 * Created by MingRen on 2016/9/1.
 */
public class User {

    private String name;

    private int num;

    private String passWord;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
}
