package com.example.yazhai1226.androidtest.mvp.presenter;

import android.content.Context;

/**
 * Created by MingRen on 2016/9/1.
 */
public interface IPresenter {

    void Login(String name,String psw);

    void clearText();

}
