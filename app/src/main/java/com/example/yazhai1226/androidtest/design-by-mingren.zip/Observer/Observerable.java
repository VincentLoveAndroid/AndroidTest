package com.example.yazhai1226.androidtest.Observer;

/**
 * Created by MingRen on 2016/8/30.
 */
public interface Observerable {
    void update();
}
