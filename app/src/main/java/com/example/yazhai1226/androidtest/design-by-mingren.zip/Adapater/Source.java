package com.example.yazhai1226.androidtest.Adapater;

/**
 * Created by MingRen on 2016/8/29.
 * email:674928145@qq.com
 * address:shenzhen
 */
public class Source {
    public void sing() {//待适配的方法
        System.out.println("singing");
    }
}
