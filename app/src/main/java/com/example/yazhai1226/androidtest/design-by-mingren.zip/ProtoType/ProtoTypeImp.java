package com.example.yazhai1226.androidtest.ProtoType;

/**
 * Created by MingRen on 2016/8/29.
 */
public class ProtoTypeImp extends ProtoType {

    public void show() {
        System.out.println("protoTypeImp");
    }
}
