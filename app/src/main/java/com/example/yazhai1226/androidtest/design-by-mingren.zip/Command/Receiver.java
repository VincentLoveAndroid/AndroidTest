package com.example.yazhai1226.androidtest.Command;

/**
 * Created by MingRen on 2016/8/30.
 */
public class Receiver {

    public void sing() {//接受者执行唱歌
        System.out.println("receiver-sing");
    }
}
