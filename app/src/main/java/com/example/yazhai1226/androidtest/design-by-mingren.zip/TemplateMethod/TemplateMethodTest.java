package com.example.yazhai1226.androidtest.TemplateMethod;

/**
 * Created by MingRen on 2016/9/2.
 */
public class TemplateMethodTest {
    public static void main(String[] args) {
        ChildMethod childMethod = new ChildMethod();
        childMethod.init();
    }
}
