package com.example.yazhai1226.androidtest.SingleTon;

/**
 * Created by MingRen on 2016/8/31.
 * 饿汉式，加载类的时候，就创建了对象
 */
public class HungrySingleTon {

    private static final HungrySingleTon hungrySingleTon = new HungrySingleTon();

    private HungrySingleTon() {}

    public HungrySingleTon getHungrySingleTon() {
        return hungrySingleTon;
    }
}
