package com.example.yazhai1226.androidtest.Adapater;

import com.example.yazhai1226.androidtest.Observer.MySubject;
import com.example.yazhai1226.androidtest.Observer.Observer1;
import com.example.yazhai1226.androidtest.Observer.Observer2;

/**
 * Created by MingRen on 2016/8/30.
 */
public class AdapterTest {
    public static void main(String args[]) {
        Adapter adapter = new Adapter();
        adapter.sing();
    }
}
