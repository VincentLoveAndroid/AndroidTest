package com.example.yazhai1226.androidtest.Factory;

/**
 * Created by MingRen on 2016/8/29.
 */
public interface Sender
{
    void send();
}
